import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd


def figure(train_result, test_result):
    fig = plt.figure(figsize=(12, 15))
    rect5 = [0.12, 0.06, 0.35, 0.25]
    rect6 = [0.6, 0.06, 0.35, 0.25]
    rect3 = [0.12, 0.38, 0.35, 0.25]
    rect4 = [0.6, 0.38, 0.35, 0.25]
    rect1 = [0.12, 0.7, 0.35, 0.25]
    rect2 = [0.6, 0.7, 0.35, 0.25]
    ax1 = plt.axes(rect1)
    ax2 = plt.axes(rect2)
    ax3 = plt.axes(rect3)
    ax4 = plt.axes(rect4)
    ax5 = plt.axes(rect5)
    ax6 = plt.axes(rect6)

    labels = ["(256,1,7)", "(512,1,7)", "(1024,1,7)", "(2048,1,7)"]
    colors = ["black", "green", "blue", "red"]

    x_value = [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
    ax1.plot(x_value, train_result[0][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax1.plot(x_value, train_result[0][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax1.plot(x_value, train_result[0][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax1.plot(x_value, train_result[0][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax1.set_ylabel(r'train Pass@1', fontsize=25)
    ax1.set_xlabel(r'train rounds', fontsize=25)
    ax1.tick_params(labelsize=25)
    ax1.set_ylim(0.2, 0.6)
    ax1.xaxis.set_major_locator(MultipleLocator(400))
    ax1.yaxis.set_major_locator(MultipleLocator(0.2))
    ax1.yaxis.get_offset_text().set_fontsize(25)
    ax1.grid()
    ax1.text(0.98, 0.02, r'Qwen-MATH',  transform=ax1.transAxes, fontsize=25, ha='right', va='bottom',
        bbox=dict(
            boxstyle='round,pad=0.3',
            facecolor='white',
            edgecolor='black',
            alpha=0.8
        )
    )

    ax2.plot(x_value, test_result[0][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax2.plot(x_value, test_result[0][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax2.plot(x_value, test_result[0][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax2.plot(x_value, test_result[0][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax2.set_ylabel(r'test Pass@1', fontsize=25)
    ax2.set_xlabel(r'train rounds', fontsize=25)
    ax2.tick_params(labelsize=25)
    ax2.set_ylim(0.2, 0.4)
    ax2.xaxis.set_major_locator(MultipleLocator(400))
    ax2.yaxis.set_major_locator(MultipleLocator(0.1))
    ax2.yaxis.get_offset_text().set_fontsize(25)
    ax2.grid()
    ax2.text(0.98, 0.02, r'Qwen-MATH', transform=ax2.transAxes, fontsize=25, ha='right', va='bottom',
             bbox=dict(
                 boxstyle='round,pad=0.3',
                 facecolor='white',
                 edgecolor='black',
                 alpha=0.8
             )
             )

    ax3.plot(x_value, train_result[1][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax3.plot(x_value, train_result[1][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax3.plot(x_value, train_result[1][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax3.plot(x_value, train_result[1][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax3.set_ylabel(r'train Pass@1', fontsize=25)
    ax3.set_xlabel(r'train rounds', fontsize=25)
    ax3.tick_params(labelsize=25)
    ax3.set_ylim(0.1, 0.9)
    ax3.xaxis.set_major_locator(MultipleLocator(400))
    ax3.yaxis.set_major_locator(MultipleLocator(0.2))
    ax3.yaxis.get_offset_text().set_fontsize(25)
    ax3.grid()
    ax3.text(0.98, 0.02, r'LLaMA-MATH', transform=ax3.transAxes, fontsize=25, ha='right', va='bottom',
             bbox=dict(
                 boxstyle='round,pad=0.3',
                 facecolor='white',
                 edgecolor='black',
                 alpha=0.8
             )
             )

    ax4.plot(x_value, test_result[1][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax4.plot(x_value, test_result[1][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax4.plot(x_value, test_result[1][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax4.plot(x_value, test_result[1][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax4.set_ylabel(r'test Pass@1', fontsize=25)
    ax4.set_xlabel(r'train rounds', fontsize=25)
    ax4.tick_params(labelsize=25)
    ax4.set_ylim(0.05, 0.40)
    ax4.xaxis.set_major_locator(MultipleLocator(400))
    ax4.yaxis.set_major_locator(MultipleLocator(0.1))
    ax4.yaxis.get_offset_text().set_fontsize(25)
    ax4.grid()
    ax4.text(0.98, 0.02, r'LLaMA-MATH', transform=ax4.transAxes, fontsize=25, ha='right', va='bottom',
             bbox=dict(
                 boxstyle='round,pad=0.3',
                 facecolor='white',
                 edgecolor='black',
                 alpha=0.8
             )
             )

    ax5.plot(x_value, train_result[2][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax5.plot(x_value, train_result[2][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax5.plot(x_value, train_result[2][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax5.plot(x_value, train_result[2][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax5.set_ylabel(r'train Pass@1', fontsize=25)
    ax5.set_xlabel(r'train rounds', fontsize=25)
    ax5.tick_params(labelsize=25)
    ax5.set_ylim(0.2, 0.4)
    ax5.xaxis.set_major_locator(MultipleLocator(400))
    ax5.yaxis.set_major_locator(MultipleLocator(0.1))
    ax5.yaxis.get_offset_text().set_fontsize(25)
    ax5.grid()
    ax5.text(0.98, 0.02, r'OLMo-MATH', transform=ax5.transAxes, fontsize=25, ha='right', va='bottom',
             bbox=dict(
                 boxstyle='round,pad=0.3',
                 facecolor='white',
                 edgecolor='black',
                 alpha=0.8
             )
             )

    ax6.plot(x_value, test_result[2][0], linewidth=3.0, label=labels[0], color=colors[0])
    ax6.plot(x_value, test_result[2][1], linewidth=3.0, label=labels[1], color=colors[1])
    ax6.plot(x_value, test_result[2][2], linewidth=3.0, label=labels[2], color=colors[2])
    ax6.plot(x_value, test_result[2][3], linewidth=3.0, label=labels[3], color=colors[3])
    ax6.set_ylabel(r'test Pass@1', fontsize=25)
    ax6.set_xlabel(r'train rounds', fontsize=25)
    ax6.tick_params(labelsize=25)
    ax6.set_ylim(0.15, 0.25)
    ax6.xaxis.set_major_locator(MultipleLocator(400))
    ax6.yaxis.set_major_locator(MultipleLocator(0.05))
    ax6.yaxis.get_offset_text().set_fontsize(25)
    ax6.grid()
    ax6.text(0.98, 0.02, r'OLMo-MATH', transform=ax6.transAxes, fontsize=25, ha='right', va='bottom',
             bbox=dict(
                 boxstyle='round,pad=0.3',
                 facecolor='white',
                 edgecolor='black',
                 alpha=0.8
             )
             )

    lines = []
    labels = []
    axLine, axLabel = ax1.get_legend_handles_labels()
    lines.extend(axLine)
    labels.extend(axLabel)
    fig.legend(lines, labels, fontsize=25, frameon=False,
               loc=(0.02, 0.96), ncol=4, handlelength=1)

    plt.savefig("./replay/MATH-batch.eps", bbox_inches='tight', dpi=600, format='eps')
    plt.show()


def get_result(data_dir):
    df = pd.read_csv(data_dir)
    mean_cols = [
        c for c in df.columns
        if "reward/mean@1" in c and not c.endswith("__MIN") and not c.endswith("__MAX")
    ]
    values = []
    for col in mean_cols:
        result = df[col].head(11)
        values.append(result.tolist())
        print(f"{values[-1][-1]}")
    return values


if __name__ == "__main__":
    train_dir = r'../result/replay/Qwen-MATH-Replay-Batch-Train.csv'
    test_dir = r'../result/replay/Qwen-MATH-Replay-Batch-Test.csv'
    Qwen_rollout_train_result = get_result(train_dir)
    Qwen_rollout_test_result = get_result(test_dir)

    train_dir = r'../result/replay/Llama-MATH-Replay-Batch-Train.csv'
    test_dir = r'../result/replay/Llama-MATH-Replay-Batch-Test.csv'
    Llama_rollout_train_result = get_result(train_dir)
    Llama_rollout_test_result = get_result(test_dir)

    train_dir = r'../result/replay/Olmo-MATH-Replay-Batch-Train.csv'
    test_dir = r'../result/replay/Olmo-MATH-Replay-Batch-Test.csv'
    Olmo_rollout_train_result = get_result(train_dir)
    Olmo_rollout_test_result = get_result(test_dir)

    train_result = [Qwen_rollout_train_result, Llama_rollout_train_result, Olmo_rollout_train_result]
    test_result = [Qwen_rollout_test_result, Llama_rollout_test_result, Olmo_rollout_test_result]
    figure(train_result, test_result)