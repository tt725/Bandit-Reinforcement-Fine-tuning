import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd


def figure(train_result, test_result):
    fig = plt.figure(figsize=(12, 5))
    rect1 = [0.12, 0.15, 0.35, 0.75]
    rect2 = [0.6, 0.15, 0.35, 0.75]
    ax1 = plt.axes(rect1)
    ax2 = plt.axes(rect2)

    labels = ["Qwen", "LLaMA", "OLMo"]
    colors = ["black", "red", "green"]

    x_value = [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
    for i in range(len(train_result)):
        ax1.plot(
            x_value,
            train_result[i],
            linewidth=3.0,
            label=labels[i],
            color=colors[i]
        )
    for i in range(len(test_result)):
        ax2.plot(
            x_value,
            test_result[i],
            linewidth=3.0,
            label=labels[i],
            color=colors[i]
        )

    ax1.set_ylabel(r'train Pass@1', fontsize=25)
    ax1.set_xlabel(r'train rounds', fontsize=25)
    ax1.tick_params(labelsize=25)
    ax1.set_ylim(0.1, 0.5)
    ax1.xaxis.set_major_locator(MultipleLocator(400))
    ax1.yaxis.set_major_locator(MultipleLocator(0.2))
    ax1.yaxis.get_offset_text().set_fontsize(25)
    ax1.grid()

    ax2.set_ylabel(r'test Pass@1', fontsize=25)
    ax2.set_xlabel(r'train rounds', fontsize=25)
    ax2.tick_params(labelsize=25)
    ax2.set_ylim(0.0, 0.4)
    ax2.xaxis.set_major_locator(MultipleLocator(400))
    ax2.yaxis.set_major_locator(MultipleLocator(0.2))
    ax2.yaxis.get_offset_text().set_fontsize(25)
    ax2.grid()

    lines = []
    labels = []
    axLine, axLabel = ax1.get_legend_handles_labels()
    lines.extend(axLine)
    labels.extend(axLabel)
    fig.legend(lines, labels, fontsize=25, frameon=False,
               loc=(0.2, 0.9), ncol=3, handlelength=1.5)

    plt.savefig("./bandit/MATH.eps", bbox_inches='tight', dpi=600, format='eps')
    plt.show()


def get_result(data_dir):
    df = pd.read_csv(data_dir)
    mean_cols = [
        c for c in df.columns
        if "reward/mean@1" in c and not c.endswith("__MIN") and not c.endswith("__MAX")
    ]
    result = df[["Step"] + mean_cols].head(11)
    values = result[mean_cols[0]].tolist()
    print(f"{values[-1]}-{values[0]}={values[-1]-values[0]}")
    return values


if __name__ == "__main__":
    train_dir = r'../result/bandit/Qwen-MATH-GRPO(32,1)-Train.csv'
    test_dir = r'../result/bandit/Qwen-MATH-GRPO(32,1)-Test.csv'
    Qwen_train_result = get_result(train_dir)
    Qwen_test_result = get_result(test_dir)

    train_dir = r'../result/bandit/Llama-MATH-GRPO(32,1)-Train.csv'
    test_dir = r'../result/bandit/Llama-MATH-GRPO(32,1)-Test.csv'
    Llama_train_result = get_result(train_dir)
    Llama_test_result = get_result(test_dir)

    train_dir = r'../result/bandit/Olmo-MATH-GRPO(32,1)-Train.csv'
    test_dir = r'../result/bandit/Olmo-MATH-GRPO(32,1)-Test.csv'
    Olmo_train_result = get_result(train_dir)
    Olmo_test_result = get_result(test_dir)

    train_result = [Qwen_train_result, Llama_train_result, Olmo_train_result]
    test_result = [Qwen_test_result, Llama_test_result, Olmo_test_result]
    figure(train_result, test_result)